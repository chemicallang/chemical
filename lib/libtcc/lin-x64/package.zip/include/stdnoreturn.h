#ifndef _STDNORETURN_H
#define _STDNORETURN_H

/* ISOC11 noreturn */
#define noreturn _Noreturn

#endif /* _STDNORETURN_H */
